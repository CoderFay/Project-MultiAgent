from dotenv import load_dotenv
load_dotenv()

import asyncio
import sys
import os


from src.agent.specialists import (
    create_researcher,
    create_analyst,
    create_writer,
)
from src.observability.cost_tracker import CostTracker


# Load environment variables
load_dotenv()


async def main():
    if len(sys.argv) < 2:
        print('Usage: python -m src.main "Your research query"')
        sys.exit(1)

    query = sys.argv[1]
    print(f"\n🔎 Starting research on: {query}\n")

    # ==============================
    # Initialize Cost Tracker
    # ==============================
    tracker = CostTracker()
    tracker.start_query(query)

    # ==============================
    # Create Agents
    # ==============================
    researcher = create_researcher()
    analyst = create_analyst()
    writer = create_writer()

    # ==============================
    # 1️⃣ Researcher
    # ==============================
    print("Running Researcher...\n")
    research_result = await researcher.run(query)

    tracker.log_agent_usage(
        agent_name="Researcher",
        model=research_result["model_used"],
        input_tokens=research_result["total_input_tokens"],
        output_tokens=research_result["total_output_tokens"],
    )

    # ==============================
    # 2️⃣ Analyst
    # ==============================
    print("\nRunning Analyst...\n")
    analyst_input = research_result["answer"]

    analysis_result = await analyst.run(analyst_input)

    tracker.log_agent_usage(
        agent_name="Analyst",
        model=analysis_result["model_used"],
        input_tokens=analysis_result["total_input_tokens"],
        output_tokens=analysis_result["total_output_tokens"],
    )

    # ==============================
    # 3️⃣ Writer
    # ==============================
    print("\nRunning Writer...\n")
    writer_input = analysis_result["answer"]

    final_result = await writer.run(writer_input)

    tracker.log_agent_usage(
        agent_name="Writer",
        model=final_result["model_used"],
        input_tokens=final_result["total_input_tokens"],
        output_tokens=final_result["total_output_tokens"],
    )

    # ==============================
    # Finish & Print
    # ==============================
    tracker.end_query()
    tracker.print_cost_breakdown()

    print("\n================ FINAL OUTPUT ================\n")
    print(final_result["answer"])
    print("\n==============================================\n")


if __name__ == "__main__":
    import asyncio
    try:
        asyncio.run(main())
    except RuntimeError as e:
        # تجاهل خطأ "Event loop is closed" على Windows فقط
        if "Event loop is closed" not in str(e):
            raise e

