import inspect
from typing import Any, Callable, Dict, Optional, List

from pydantic import BaseModel, create_model, ValidationError


# =====================================================
# Tool Wrapper
# =====================================================
class Tool:
    """A callable tool with automatic Pydantic validation and OpenAI schema export."""

    def __init__(self, name: str, func: Callable, description: str):
        self.name = name
        self.func = func
        self.description = description
        self.model = self._create_pydantic_model(func)

    # -------------------------------------------------
    # Create Pydantic Model From Function Signature
    # -------------------------------------------------
    def _create_pydantic_model(self, func: Callable) -> type(BaseModel):
        sig = inspect.signature(func)
        fields = {}

        for param_name, param in sig.parameters.items():
            if param_name == "self":
                continue

            annotation = param.annotation
            if annotation == inspect.Parameter.empty:
                annotation = str

            default = param.default
            if default == inspect.Parameter.empty:
                fields[param_name] = (annotation, ...)
            else:
                fields[param_name] = (annotation, default)

        return create_model(f"{self.name}Schema", **fields)

    # -------------------------------------------------
    # Convert To OpenAI Tool Schema
    # -------------------------------------------------
    def to_openai_schema(self) -> dict:
        """
        Returns schema in OpenAI-compatible format.
        Works with OpenRouter as well.
        """
        schema = self.model.model_json_schema()

        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": schema.get("properties", {}),
                    "required": schema.get("required", []),
                    "additionalProperties": False,
                },
            },
        }

    # -------------------------------------------------
    # Execute Tool With Validation
    # -------------------------------------------------
    def execute(self, **kwargs) -> Any:
        try:
            validated_args = self.model(**kwargs)
            return self.func(**validated_args.model_dump())
        except ValidationError as e:
            return f"Validation error in tool '{self.name}': {str(e)}"
        except Exception as e:
            return f"Execution error in tool '{self.name}': {str(e)}"


# =====================================================
# Tool Registry
# =====================================================
class ToolRegistry:
    """Central registry for all tools in the system."""

    def __init__(self):
        self._tools: Dict[str, Tool] = {}
        self._categories: Dict[str, List[str]] = {}

    # -------------------------------------------------
    # Decorator Registration
    # -------------------------------------------------
    def register(self, name: str, description: str, category: str = "general"):
        """
        Usage:

        @registry.register(
            name="search",
            description="Search the web",
            category="research"
        )
        def search(query: str):
            ...
        """

        def decorator(func: Callable):
            tool = Tool(name=name, func=func, description=description)
            self._tools[name] = tool

            if category not in self._categories:
                self._categories[category] = []

            self._categories[category].append(name)
            return func

        return decorator

    # -------------------------------------------------
    # Getters
    # -------------------------------------------------
    def get_tool(self, name: str) -> Optional[Tool]:
        return self._tools.get(name)

    def get_all_tools(self) -> List[Tool]:
        return list(self._tools.values())

    def get_tools_by_category(self, category: str) -> List[Tool]:
        tool_names = self._categories.get(category, [])
        return [self._tools[name] for name in tool_names]

    # -------------------------------------------------
    # Execute Tool By Name
    # -------------------------------------------------
    def execute_tool(self, name: str, **kwargs) -> Any:
        tool = self.get_tool(name)
        if not tool:
            return f"Tool '{name}' not found."
        return tool.execute(**kwargs)


# =====================================================
# Global Registry Instance
# =====================================================
registry = ToolRegistry()
