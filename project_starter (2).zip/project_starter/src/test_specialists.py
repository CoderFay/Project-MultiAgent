# test_specialists.py
from tools.registry import registry
from agent.specialists import create_researcher, create_analyst, create_writer

def test_agents_setup():
    # نسوي وكلاء
    researcher = create_researcher()
    analyst = create_analyst()
    writer = create_writer()

    agents = [researcher, analyst, writer]

    for agent in agents:
        print(f"Agent: {agent.agent_name}")
        print(f"  Model: {agent.model}")
        print(f"  Max Steps: {agent.max_steps}")
        print(f"  System Prompt: {agent.system_prompt[:60]}...")
        if hasattr(agent, "tools") and agent.tools:
            print(f"  Tools: {[tool.name for tool in agent.tools]}")
        else:
            print("  Tools: None")
        print("-" * 50)


if __name__ == "__main__":
    test_agents_setup()
