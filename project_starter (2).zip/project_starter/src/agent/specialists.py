import os
from src.agent.observable_agent import ObservableAgent

# Uncomment when registry is ready
# from src.tools.registry import registry


DEFAULT_MODEL = os.getenv("MODEL_NAME", "openai/gpt-4o-mini")


# ==========================================
# Researcher Agent
# ==========================================
def create_researcher(model: str = None, max_steps: int = 15):
    """
    The Researcher:
    - Finds information
    - Retrieves data
    - Summarizes sources
    """

    system_prompt = (
        "You are a world-class research agent.\n"
        "Your responsibilities:\n"
        "- Search for relevant information\n"
        "- Retrieve factual data\n"
        "- Summarize findings clearly\n"
        "- Always prioritize accuracy and citations when possible."
    )

    # When registry is ready:
    # research_tools = registry.get_tools_by_category("research")

    research_tools = []

    return ObservableAgent(
        model=model or DEFAULT_MODEL,
        max_steps=max_steps,
        agent_name="Researcher",
        system_prompt=system_prompt,
        tools=research_tools,
        verbose=True,
    )


# ==========================================
# Analyst Agent
# ==========================================
def create_analyst(model: str = None, max_steps: int = 20):
    """
    The Analyst:
    - Evaluates information
    - Cross-references findings
    - Identifies patterns & inconsistencies
    """

    system_prompt = (
        "You are an expert analysis agent.\n"
        "Your responsibilities:\n"
        "- Evaluate research results critically\n"
        "- Cross-reference information\n"
        "- Identify patterns, trends, and inconsistencies\n"
        "- Provide structured analytical insights."
    )

    # analyst_tools = registry.get_tools_by_category("analysis")
    analyst_tools = []

    return ObservableAgent(
        model=model or DEFAULT_MODEL,
        max_steps=max_steps,
        agent_name="Analyst",
        system_prompt=system_prompt,
        tools=analyst_tools,
        verbose=True,
    )


# ==========================================
# Writer Agent
# ==========================================
def create_writer(model: str = None, max_steps: int = 5):
    """
    The Writer:
    - Synthesizes analysis
    - Produces structured output
    - Polishes final response
    """

    system_prompt = (
        "You are a professional writing agent.\n"
        "Your responsibilities:\n"
        "- Synthesize research and analysis\n"
        "- Produce clear, structured text\n"
        "- Use headings and logical flow\n"
        "- Write in a polished and professional tone."
    )

    # writer_tools = registry.get_tools_by_category("writing")
    writer_tools = []

    return ObservableAgent(
        model=model or DEFAULT_MODEL,
        max_steps=max_steps,
        agent_name="Writer",
        system_prompt=system_prompt,
        tools=writer_tools,
        verbose=True,
    )


# ==========================================
# Quick Test
# ==========================================
if __name__ == "__main__":
    import asyncio

    async def test_agents():
        researcher = create_researcher(max_steps=2)
        analyst = create_analyst(max_steps=2)
        writer = create_writer(max_steps=1)

        print(await researcher.run("Find information about AI agents"))
        print(await analyst.run("Analyze research results about AI adoption"))
        print(await writer.run("Write a structured summary about AI agents"))

    asyncio.run(test_agents())
